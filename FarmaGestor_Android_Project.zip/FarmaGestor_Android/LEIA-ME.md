# FarmaGestor Android
Aplicação Android nativa (Kotlin + SQLite local) para vendas e distribuição comercial: produtos, stock e entradas, clientes, fornecedores, vendas, pagamentos e relatórios gerais.

## Como construir e instalar
1. Instale Android Studio: https://developer.android.com/studio
2. Extraia o ZIP e abra a pasta `FarmaGestor_Android` no Android Studio.
3. Aceite a sincronização do Gradle e instale o Android SDK 35 se for solicitado.
4. Escolha **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de teste aparecerá em `app/build/outputs/apk/debug/app-debug.apk`.
6. Copie o APK para o Android. Abra-o e permita instalar aplicações desta origem se o sistema solicitar.

## Utilização
- Início: indicadores de vendas e stock.
- Produtos: cadastrar/editar produtos e registar entradas de stock.
- Vendas: escolher produto, quantidade, cliente e método de pagamento; o stock diminui automaticamente.
- Vendas: registar recebimentos posteriores de dívidas.
- Mais: clientes, fornecedores, relatórios e histórico de entradas.
- A base de dados `farmagestor.db` fica no armazenamento privado da aplicação no telefone.

## Importante
Este é um projecto inicial de gestão comercial, não um sistema de facturação fiscal certificado. Não inclui sincronização entre dispositivos, integração real com M-Pesa/e-Mola, cópias automáticas, gestão por lotes, impressão fiscal, utilizadores/permissões ou exportação PDF/Excel. Valide requisitos fiscais, farmacêuticos e de protecção de dados em Moçambique antes do uso comercial. O APK não foi compilado/testado neste ambiente; deve ser construído no Android Studio e testado no seu telefone.
