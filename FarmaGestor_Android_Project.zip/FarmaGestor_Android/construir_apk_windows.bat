@echo off
echo Abra esta pasta no Android Studio e seleccione Build APK.
pause
