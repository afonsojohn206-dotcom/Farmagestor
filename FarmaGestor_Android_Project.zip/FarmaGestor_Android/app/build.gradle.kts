plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace="mz.farmagestor"
    compileSdk=35
    defaultConfig { applicationId="mz.farmagestor"; minSdk=23; targetSdk=35; versionCode=1; versionName="1.0.0" }
}
